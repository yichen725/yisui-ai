# 逸碎AI - 完整前后端代码 v1.0

## 项目结构

```
yisui-ai-full/
├── frontend/              # 前端代码（部署到 GitHub Pages）
│   ├── index.html         # 主页面（包含所有前端逻辑）
│   ├── manifest.json      # PWA 配置
│   ├── sw.js              # Service Worker（离线缓存）
│   └── icons/             # 应用图标
│       ├── icon-192.png
│       └── icon-512.png
├── backend/               # 后端代码（部署到 Railway/其他平台）
│   ├── server.js          # 后端服务（API转发 + 卡密验证）
│   ├── package.json       # 依赖配置
│   └── cards.json         # 卡密数据
├── README.md              # 本说明文件
└── 部署指南.md            # 详细部署指南
```

## 功能特性

### 前端
- 5个人格预设：默认、鲸鱼娘、鲸鱼娘·绝对顺从、猫娘、林殷
- 图片上传与识别
- 自动模型路由（有图用 Vision 版，无图用 Pro 版）
- 会话管理（新建、删除、搜索、导出、导入）
- 记忆功能
- 背景图片自定义
- 温度/max_tokens 调节
- 自定义系统提示词
- PWA 支持（可添加到主屏幕，像App一样使用）
- 响应式设计（支持手机和电脑）

### 后端
- API 转发（隐藏 API Key，支持流式响应）
- 卡密验证系统
- CORS 允许所有来源
- 支持多模型（DeepSeek V4 系列、GPT-4o、通义千问等）
- 自动模型路由（有图自动切换视觉模型）

## 快速部署

### 前端部署（GitHub Pages）
1. 将 `frontend/` 目录的所有文件上传到 GitHub 仓库
2. 在仓库设置中启用 GitHub Pages
3. 访问 `https://<用户名>.github.io/<仓库名>/`

### 后端部署（Railway）
1. 将 `backend/` 目录的所有文件上传到 GitHub 仓库
2. 在 Railway 中导入该仓库
3. 设置环境变量：
   - `DEEPSEEK_KEY`：你的 DeepSeek API Key
   - `OPENAI_KEY`：你的 OpenAI API Key（可选）
4. 部署完成后获取后端地址
5. 修改前端 `index.html` 中的 `defaultConfig.chatApiUrl` 为你的后端地址

### 本地运行
```bash
cd backend
npm install
npm start
# 后端运行在 http://localhost:3000
```

## 卡密管理

编辑 `backend/cards.json` 文件，格式如下：
```json
[
  {"key": "卡密1", "used": false},
  {"key": "卡密2", "used": false}
]
```

- `used: false` 表示未使用
- `used: true` 表示已使用

## 技术栈

- 前端：纯 HTML/CSS/JavaScript + marked + DOMPurify + highlight.js
- 后端：Node.js + Express + CORS
- 部署：GitHub Pages（前端）+ Railway（后端）
- AI 模型：DeepSeek V4 系列

## 版本信息

- 版本：v1.0.0
- 更新日期：2026-08-29
